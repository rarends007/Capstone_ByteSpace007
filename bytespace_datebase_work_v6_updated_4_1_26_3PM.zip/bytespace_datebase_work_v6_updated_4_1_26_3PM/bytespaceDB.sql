-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: db:3306
-- Generation Time: Mar 30, 2026 at 09:51 PM
-- Server version: 9.4.0
-- PHP Version: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bytespaceDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `action`
--

CREATE TABLE `action` (
  `action_id` int NOT NULL,
  `action_type` varchar(20) NOT NULL,
  `action_type_desc` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `action`
--

INSERT INTO `action` (`action_id`, `action_type`, `action_type_desc`) VALUES
(1, 'LOGIN', 'Player logged into the realm'),
(2, 'LOGOUT', 'Player disconnected from session'),
(3, 'CREATE_POST', 'Player published a new memory fragment'),
(4, 'LIKE_POST', 'Player hearted / favorited a memory'),
(5, 'COMMENT', 'Player inscribed a comment rune'),
(6, 'SHARE_POST', 'Player echoed / reshared a fragment'),
(7, 'DELETE_POST', 'Player deleted their post'),
(8, 'UPDATE_PROFILE', 'Player altered their adventurer profile'),
(9, 'REPORT_USER', 'Player submitted a karen grief'),
(10, 'REPORT_CONTENT', 'Player submitted an anomaly report'),
(11, 'SEND_MESSAGE', 'Player whispered / sent a private scroll'),
(12, 'OPEN_MESSAGE', 'Player opened a message'),
(13, 'ADD_FRIEND', 'Player bound their fate to another adventurer'),
(14, 'REMOVE_FRIEND', 'Player unbound their fate to another adventurer');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment_id` int NOT NULL,
  `commenting_user_id` int DEFAULT NULL,
  `post_id` int NOT NULL,
  `comment_text` varchar(500) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`comment_id`, `commenting_user_id`, `post_id`, `comment_text`) VALUES
(1, 3, 1, 'Eat shit loser.'),
(2, 4, 1, 'Missing out hurts my soul'),
(3, 5, 2, 'Classic midnight grind playlist material right here'),
(4, 2, 5, 'Epic! What build finally broke it?'),
(5, 6, 5, 'I sniped that poser in VAIL.'),
(6, 1, 3, 'Grateful to all adventurers helping keep the realm wholesome'),
(7, 3, 6, 'That’s Fu**ing right? Iceland DLC is insane');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `image_id` int NOT NULL,
  `image_path` varchar(500) DEFAULT NULL,
  `post_id` int DEFAULT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `log_id` int NOT NULL,
  `logged_user_id` int NOT NULL,
  `logged_action_id` int NOT NULL,
  `log_text` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`log_id`, `logged_user_id`, `logged_action_id`, `log_text`) VALUES
(1, 1, 1, 'GameMaster logged in from secure node'),
(2, 2, 3, 'Published Sakura Prime event clear screenshot'),
(3, 5, 5, 'Inscribed comment on bug-slaying trophy post'),
(4, 3, 4, 'Favorited Neon Rain district grind screenshot'),
(5, 1, 8, 'Opened moderation queue — 2 pending anomaly reports'),
(6, 4, 7, 'Updated profile status → new seasonal bio');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `message_id` int NOT NULL,
  `message_text` varchar(1000) NOT NULL,
  `sender_id` int DEFAULT NULL,
  `reciever_id` int DEFAULT NULL,
  `timestamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`message_id`, `message_text`, `sender_id`, `reciever_id`, `timestamp`) VALUES
(1, '[Party] VoidCoder → PixelSlayer: yo you suck newb', 5, 3, '2026-04-12 01:14:22'),
(2, '[Whisper] PixelSlayer → VoidCoder: Dude you suck.', 3, 5, '2026-04-12 01:17:09'),
(3, '[Guild] MatchaVault → SakuraBloom: those sakura coords are S-tier — drop a waypoint?', 4, 2, '2026-04-12 09:42:35'),
(4, '[Whisper] SakuraBloom → MatchaVault: Ueno Park zone IRL — spring seasonal event is peak rn', 2, 4, '2026-04-12 09:45:11'),
(5, '[System] GameMaster → MatchaVault: [Maintenance Alert] Realm going offline Sat 03:00–05:00 UTC for patch', 1, 4, '2026-04-12 11:20:00'),
(6, '[Quest Update] MapWanderer → VoidCoder: New screenshot POI unlocked: kill canyon — worth the travel debuff?', 6, 5, '2026-04-12 14:55:00'),
(7, '[Party] VoidCoder → MapWanderer: 100%. Adding to exploration journal. Pack frost potions — weather DoT is nasty', 5, 6, '2026-04-12 15:02:17'),
(8, '[Trade] MatchaVault → SakuraBloom: WTS 3x limited matcha emotes — trading for your rare sakura filter ', 4, 2, '2026-04-12 16:10:44'),
(9, '[Admin Whisper] GameMaster → PixelSlayer: Report on \"randomacc42\" processed. +25 SJW Points added', 1, 3, '2026-04-12 10:05:00');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notification_id` int NOT NULL,
  `notification_text` varchar(1000) NOT NULL,
  `notified_user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notification_id`, `notification_text`, `notified_user_id`) VALUES
(1, 'Achievement Unlocked → Sakura Spotter I: First cherry blossom memory favorited ×5', 2),
(2, 'SweetLoot favorited your Legendary Strawberry Matcha pull  🍓✨', 4),
(3, 'VoidCoder whispered about your bug kill: \"gg wp on that boss\"', 5),
(4, 'New Follower Alert: MapWanderer has joined your party!', 3),
(5, 'Harrassment Report filed against your PixelSlayer acct screenshot, warning', 3),
(6, 'Realm Broadcast – GameMaster: Maintenance window in 2 hours — save & logout recommended', 1),
(7, 'Moderator Rank Up! +1 Authority Shard unlocked', 4),
(8, 'Daily Quest \"Share a Memory\" completed → 50 XP & minor loot box', 5),
(9, 'Critical Comment Chain: 7 hearts landed → Title \"Echo Lord\" unlocked', 6),
(10, 'Boss Defeat: Memory Leak Sovereign → +200 XP  + \"Bugbane\" title earned', 5),
(11, 'New Cosmetic: PixelRain Cape auto-equipped  (+15 night-aura potency)', 3);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int NOT NULL,
  `user_id` int NOT NULL,
  `image_file_path` varchar(150) DEFAULT NULL,
  `post_text` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `user_id`, `image_file_path`, `post_text`) VALUES
(1, 2, 'C:/capstone/2026/media/2026/04/sakura-boss-arena.jpg', 'Cleared the Sakura Prime event — full bloom phase was gorgeous'),
(2, 3, 'C:/capstone/2026/media/2026/04/neon-rain-dungeon.png', 'Rain + neon district at 3AM — perfect grinding spot'),
(3, 1, NULL, 'Server Notice: Please use the Report Anomaly tool instead of starting PvP in global chat.'),
(4, 4, 'C:/capstone/2026/media/2026/04/strawberry-matcha-legendary.jpg', 'Pulled the limited Strawberry Matcha skin — worth every gem '),
(5, 5, 'C:/capstone/2026/media/2026/04/bugslayer-trophy.png', 'Finally downed the UseAfterFree boss after 14h raid  '),
(6, 6, 'C:/capstone/2026/media/2026/04/fjord-canyon-raid.jpg', 'New zone discovered: Fjaðrárgljúfur — 10/10 visuals, bring cold resist');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `profile_name` varchar(100) NOT NULL,
  `user_id_owned_by` int NOT NULL,
  `profile_status` varchar(100) DEFAULT NULL,
  `profile_photo_path` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`profile_name`, `user_id_owned_by`, `profile_status`, `profile_photo_path`) VALUES
('GameMaster', 1, 'Game Site Master • watching over Bytespace', NULL),
('PixelSlayer', 2, 'cherry blossom memory collector', NULL),
('sarah_m', 6, 'World explorer • new zone unlocked every season', NULL),
('SweetLoot', 3, '3AM dungeon runner • code & synthwave', NULL),
('VoidCoder', 4, 'Dessert archivist • currently hoarding limited banners', NULL),
('ZoneMapper', 5, 'Dark theme zealot • debugging is my raid', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_id` int NOT NULL,
  `report_reason` varchar(100) NOT NULL,
  `report_title` varchar(100) DEFAULT NULL,
  `report_text` varchar(1000) DEFAULT NULL,
  `reporting_user` int NOT NULL,
  `reported_username` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`report_id`, `report_reason`, `report_title`, `report_text`, `reporting_user`, `reported_username`) VALUES
(1, 'SPAM', 'Macro spam in global', 'Same gold-seller link posted 12× today', 5, 'VoidCoder'),
(2, 'HARRASSMENT', 'Targeted flame in thread', 'Multiple slurs directed at another player', 2, 'sarah_m'),
(3, 'MISINFORMATION', 'False cure claim in chat', 'Claiming turmeric potion cures end-game cancer', 4, 'SweetLoot');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int NOT NULL,
  `username` varchar(30) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `middlename` varchar(25) DEFAULT NULL,
  `lastname` varchar(25) NOT NULL,
  `credential` varchar(500) NOT NULL,
  `employee_id` varchar(10) DEFAULT NULL,
  `is_banned` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `firstname`, `middlename`, `lastname`, `credential`, `employee_id`, `is_banned`) VALUES
(1, 'GameMaster', 'Robert', NULL, 'King', '922ee279a105db4ec5c7172dff2452c9$4096$b90fdc50d7741471f15dee66090715dea34eba042ee9f7450e5dcb3d8636f85a', 'EMP001', 0),
(2, 'sarah_m', 'Sarah', 'Marie', 'Chen', '922ee279a105db4ec5c7172dff2452c9$4096$b90fdc50d7741471f15dee66090715dea34eba042ee9f7450e5dcb3d8636f85a', NULL, 0),
(3, 'PixelSlayer', 'Alex', NULL, 'Rivera', '922ee279a105db4ec5c7172dff2452c9$4096$b90fdc50d7741471f15dee66090715dea34eba042ee9f7450e5dcb3d8636f85a', NULL, 0),
(4, 'SweetLoot', 'Jennifer', NULL, 'Torres', '922ee279a105db4ec5c7172dff2452c9$4096$b90fdc50d7741471f15dee66090715dea34eba042ee9f7450e5dcb3d8636f85a', 'EMP017', 0),
(5, 'VoidCoder', 'Marcus', 'James', 'Lee', '922ee279a105db4ec5c7172dff2452c9$4096$b90fdc50d7741471f15dee66090715dea34eba042ee9f7450e5dcb3d8636f85a', NULL, 0),
(6, 'ZoneMapper', 'Emma', 'Rose', 'Patel', '922ee279a105db4ec5c7172dff2452c9$4096$b90fdc50d7741471f15dee66090715dea34eba042ee9f7450e5dcb3d8636f85a', NULL, 0),
(7, 'JackBeast', 'Oleksandr', NULL, 'Khokhulia', '922ee279a105db4ec5c7172dff2452c9$4096$b90fdc50d7741471f15dee66090715dea34eba042ee9f7450e5dcb3d8636f85a', NULL, 0),
(8, 'AimBot666', 'Scout', NULL, 'Ernst', '922ee279a105db4ec5c7172dff2452c9$4096$b90fdc50d7741471f15dee66090715dea34eba042ee9f7450e5dcb3d8636f85a', NULL, 0),
(9, 'KyleTheMan', 'Kyle', NULL, 'Stuart', '922ee279a105db4ec5c7172dff2452c9$4096$b90fdc50d7741471f15dee66090715dea34eba042ee9f7450e5dcb3d8636f85a', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_followers`
--

CREATE TABLE `user_followers` (
  `user_follower_id` int NOT NULL,
  `user_id` int NOT NULL,
  `following_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_followers`
--

INSERT INTO `user_followers` (`user_follower_id`, `user_id`, `following_id`) VALUES
(1, 1, 2),
(2, 1, 6),
(3, 1, 7),
(4, 3, 2),
(5, 3, 4),
(6, 5, 2),
(7, 5, 3),
(8, 5, 9),
(9, 7, 8),
(10, 9, 5);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `user_id` int NOT NULL,
  `username` varchar(30) NOT NULL,
  `rolename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`user_id`, `username`, `rolename`) VALUES
(1, 'GameMaster', 'ADMIN'),
(2, 'sarah_m', 'MEMBER'),
(3, 'PixelSlayer', 'MEMBER'),
(4, 'SweetLoot', 'MEMBER'),
(5, 'VoidCoder', 'MEMBER'),
(6, 'ZoneMapper', 'MEMBER'),
(7, 'JackBeast', 'ADMIN'),
(8, 'AimBot666', 'ADMIN'),
(9, 'KyleTheMan', 'ADMIN');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `action`
--
ALTER TABLE `action`
  ADD PRIMARY KEY (`action_id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `fk_comment_user` (`commenting_user_id`),
  ADD KEY `fk_comment_post` (`post_id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `fk_image_post` (`post_id`),
  ADD KEY `fk_image_user` (`user_id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `fk_log_user` (`logged_user_id`),
  ADD KEY `fk_log_action` (`logged_action_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `fk_message_user_sender` (`sender_id`),
  ADD KEY `fk_message_user_reciever` (`reciever_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `fk_notificatoin_user` (`notified_user_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `fk_post_user` (`user_id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`profile_name`),
  ADD KEY `fk_profile_user` (`user_id_owned_by`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `fk_report_user` (`reporting_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `uq_user_username` (`username`);

--
-- Indexes for table `user_followers`
--
ALTER TABLE `user_followers`
  ADD PRIMARY KEY (`user_follower_id`),
  ADD KEY `userID_FK_user` (`user_id`),
  ADD KEY `followID_FK_user` (`following_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`user_id`,`username`,`rolename`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `action`
--
ALTER TABLE `action`
  MODIFY `action_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `comment_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `image_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `log_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `message_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notification_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `report_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_followers`
--
ALTER TABLE `user_followers`
  MODIFY `user_follower_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `fk_comment_post` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_comment_user` FOREIGN KEY (`commenting_user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `fk_image_post` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`),
  ADD CONSTRAINT `fk_image_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `fk_log_action` FOREIGN KEY (`logged_action_id`) REFERENCES `action` (`action_id`),
  ADD CONSTRAINT `fk_log_user` FOREIGN KEY (`logged_user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `fk_message_user_reciever` FOREIGN KEY (`reciever_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `fk_message_user_sender` FOREIGN KEY (`sender_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `fk_notificatoin_user` FOREIGN KEY (`notified_user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `fk_post_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `fk_profile_user` FOREIGN KEY (`user_id_owned_by`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `fk_report_user` FOREIGN KEY (`reporting_user`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `user_followers`
--
ALTER TABLE `user_followers`
  ADD CONSTRAINT `followID_FK_user` FOREIGN KEY (`following_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `userID_FK_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_role`
--
ALTER TABLE `user_role`
  ADD CONSTRAINT `fk_user_role_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
